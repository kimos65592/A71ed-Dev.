export type Intent =
  | 'REMEMBER'
  | 'RECALL'
  | 'STUDY'
  | 'PLANNING'
  | 'GOAL_QUERY'
  | 'GOAL_CREATE'
  | 'DEVICE_ACTION'
  | 'GREETING'
  | 'GENERAL';

export interface Understanding {
  intent: Intent;
  entities: string[];
  constraints: string[];
  urgency: number;
  emotionalStateEstimate: { label: string; confidence: number };
  ambiguity: number;
  memoryType?: 'USER_FACT' | 'USER_PREFERENCE';
  memoryText?: string;
  requestedSubject?: string;
}

export interface ReasoningProvider {
  name: string;
  understand(input: string, context: string): Promise<Understanding>;
  answer(prompt: string, context: string): Promise<string>;
}

const normalize = (value: string) => value
  .toLowerCase()
  .replace(/[ًٌٍَُِّْـ]/g, '')
  .replace(/[إأآا]/g, 'ا')
  .replace(/ى/g, 'ي')
  .trim();

const cleanMemoryText = (value: string) => value
  .replace(/^(تذكر|افتكر|خلي في بالك|احفظ)\s*/i, '')
  .replace(/^(ان|أن|اني|أني|انني|أنني)\s*/i, '')
  .replace(/[.!؟]+$/g, '')
  .trim();

export class LocalRuleEngine implements ReasoningProvider {
  name = 'LOCAL_COGNITIVE_ENGINE_V1';

  async understand(input: string, _context: string): Promise<Understanding> {
    const text = normalize(input);
    const urgency = /(دلوقتي|الان|urgent|asap|متاخر|ضروري)/.test(text) ? 0.9 : 0.25;

    if (/^(تذكر|افتكر|خلي في بالك|احفظ)/.test(text)) {
      const raw = cleanMemoryText(input);
      const preference = /احب|بحب|افضل|بفضل|المفضل|هوايتي|ميولي/.test(text);
      return {
        intent: 'REMEMBER',
        entities: [],
        constraints: [],
        urgency,
        emotionalStateEstimate: { label: 'NEUTRAL', confidence: 0.8 },
        ambiguity: raw.length < 3 ? 0.65 : 0.05,
        memoryType: preference ? 'USER_PREFERENCE' : 'USER_FACT',
        memoryText: raw,
      };
    }

    if (/ما هو هدفي|ما هدفي|ايه هدفي|ايه الهدف|الهدف الحالي|هدفي الحالي/.test(text)) {
      return this.base('GOAL_QUERY', urgency, 0.03);
    }

    if (/ماذا احب|ايه اللي بحبه|ايه الى بحبه|تفضيلاتي|ماذا تذكر عني|ماذا تعرف عني|افتكر ايه عني/.test(text)) {
      return this.base('RECALL', urgency, 0.08);
    }

    if (/خطط لي|اعمل لي خطة|اعمل خطة|خطة لي|plan/.test(text)) {
      const subject = /مذاكر|دراسه|دراسة|فيزياء|كيمياء|عربي|انجليزي|برمجه|برمجة/.exec(text)?.[0];
      return { ...this.base('PLANNING', urgency, 0.08), requestedSubject: subject };
    }

    if (/ذاكر|مذاكرة|مذاكر|دراسة|ادرس|study/.test(text)) {
      const subject = /فيزياء|كيمياء|عربي|انجليزي|رياضيات|برمجه|برمجة/.exec(text)?.[0];
      return { ...this.base('STUDY', urgency, 0.1), requestedSubject: subject };
    }

    if (/افتح|شغل|اقفل|launch|open/.test(text)) {
      return this.base('DEVICE_ACTION', urgency, 0.12);
    }

    if (/^(اهلا|اهلا يا جارفس|هاي|hello|hi|السلام عليكم)/.test(text)) {
      return this.base('GREETING', urgency, 0.05);
    }

    return this.base('GENERAL', urgency, 0.22);
  }

  private base(intent: Intent, urgency: number, ambiguity: number): Understanding {
    return {
      intent,
      entities: [],
      constraints: [],
      urgency,
      emotionalStateEstimate: { label: 'NEUTRAL', confidence: 0.65 },
      ambiguity,
    };
  }

  async answer(prompt: string, context: string) {
    const data = JSON.parse(context) as { memories?: Array<{ text: string }> };
    const memoryCount = data.memories?.length ?? 0;
    if (memoryCount > 0) {
      return `فهمت طلبك وسأبنيه على السياق المتاح لدي.\n\n${prompt}`;
    }
    return `فهمت طلبك، لكن لا توجد لدي معلومات كافية عن السياق بعد.\n\n${prompt}`;
  }
}
