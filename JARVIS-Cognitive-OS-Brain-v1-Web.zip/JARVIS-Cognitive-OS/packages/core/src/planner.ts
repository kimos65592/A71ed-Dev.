import type {Goal,Plan,Prediction,Decision,Memory} from './types.js';

export function generatePlans(goal:Goal, memories:Memory[], constraints:string[]): Plan[] {
  const historyPenalty=memories.some(m=>m.type==='FAILURE' && /plan|study|مذاكرة|سريع|fast/i.test(m.text)) ? 0.08 : 0;
  const context=constraints.length?` مع مراعاة: ${constraints.join('، ')}`:'';
  return [
    {id:crypto.randomUUID(),label:'FAST',steps:[`تحديد الحد الأدنى القابل للإنجاز${context}`,`تنفيذ أهم خطوة أولًا`,`مراجعة سريعة وإغلاق المهمة`],dependencies:[],estimatedEffort:30,expectedOutcome:`إنجاز جوهر الهدف بسرعة`,risk:0.35+historyPenalty,confidence:0.72,recoveryStrategy:'تقليص النطاق والانتقال لأول خطوة مكتملة'},
    {id:crypto.randomUUID(),label:'BALANCED',steps:[`تحديد النتيجة النهائية${context}`,`تقسيم الهدف إلى خطوات`,`تنفيذ مع فواصل تحقق`,`مراجعة النتيجة وإعادة التخطيط عند الحاجة`],dependencies:[],estimatedEffort:60,expectedOutcome:`توازن بين السرعة والجودة`,risk:0.2,confidence:0.84,recoveryStrategy:'إعادة ترتيب الخطوات وتقليل الجهد في الخطوة الأعلى كلفة'},
    {id:crypto.randomUUID(),label:'DEEP',steps:[`جمع السياق${context}`,`تحليل البدائل`,`تنفيذ متدرج مع تحقق بعد كل خطوة`,`استخراج درس قابل لإعادة الاستخدام`],dependencies:[],estimatedEffort:100,expectedOutcome:`جودة أعلى وفهم أعمق`,risk:0.15,confidence:0.87,recoveryStrategy:'التوقف عند أول فشل وتحويله إلى فرضية جديدة'}
  ];
}

export function predict(plan:Plan,goal:Goal):Prediction{ return {planId:plan.id,benefit:Math.min(1,plan.confidence+0.1),cost:plan.estimatedEffort/100,risk:plan.risk,probabilityOfSuccess:Math.max(0,Math.min(1,plan.confidence-plan.risk*0.35)),dependencies:plan.dependencies,failureModes:plan.label==='FAST'?['ضغط زمني','جودة أقل']:['تضخم النطاق','إرهاق'],recoveryPossibilities:[plan.recoveryStrategy]}; }
export function decide(plans:Plan[],predictions:Prediction[],prefs:{speed:number;quality:number;riskAversion:number},memories:Memory[]):Decision{
  const prevFailure=memories.filter(m=>m.type==='FAILURE').length>0;
  const scored=predictions.map(p=>{const plan=plans.find(x=>x.id===p.planId)!; const score=plan.confidence*0.35+p.benefit*0.25+p.probabilityOfSuccess*0.2+(1-p.risk)*0.1+(1-p.cost)*prefs.speed*0.05-plan.risk*prefs.riskAversion*0.05+(plan.label==='DEEP'?prefs.quality*0.03:0)-(prevFailure&&plan.label==='FAST'?0.08:0);return {plan,score};}).sort((a,b)=>b.score-a.score)[0];
  return {planId:scored.plan.id,score:scored.score,reasons:[`حقق توافقًا جيدًا مع الهدف`,prevFailure&&scored.plan.label!=='FAST'?'تم تخفيض أولوية السرعة بسبب فشل سابق':'لا توجد إشارة قوية لتغيير الأولوية',`المخاطرة المقدرة ${(scored.plan.risk*100).toFixed(0)}%`],confidence:scored.plan.confidence,reversible:true};
}
