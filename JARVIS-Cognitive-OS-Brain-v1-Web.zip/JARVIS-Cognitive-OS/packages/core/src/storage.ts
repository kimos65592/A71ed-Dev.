import type {Memory, Goal, PersonalitySettings, JarvisEvent, WorldModel, SelfModel} from './types.js';

export interface StorageAdapter {
  get<T>(key:string):Promise<T|undefined>;
  set<T>(key:string,value:T):Promise<void>;
  delete(key:string):Promise<void>;
}

export class MemoryStorage implements StorageAdapter {
  private map=new Map<string,unknown>();
  async get<T>(key:string){return this.map.get(key) as T|undefined;}
  async set<T>(key:string,value:T){this.map.set(key,value);}
  async delete(key:string){this.map.delete(key);}
}

export class IndexedDbStorage implements StorageAdapter {
  private dbp: Promise<IDBDatabase>;
  constructor(name='jarvis-db') {
    this.dbp=new Promise((resolve,reject)=>{
      const r=indexedDB.open(name,1); r.onupgradeneeded=()=>r.result.createObjectStore('kv'); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
    });
  }
  async get<T>(key:string){const db=await this.dbp;return new Promise<T|undefined>((res,rej)=>{const tx=db.transaction('kv','readonly');const q=tx.objectStore('kv').get(key);q.onsuccess=()=>res(q.result as T|undefined);q.onerror=()=>rej(q.error);});}
  async set<T>(key:string,value:T){const db=await this.dbp;return new Promise<void>((res,rej)=>{const tx=db.transaction('kv','readwrite');tx.objectStore('kv').put(value,key);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);});}
  async delete(key:string){const db=await this.dbp;return new Promise<void>((res,rej)=>{const tx=db.transaction('kv','readwrite');tx.objectStore('kv').delete(key);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);});}
}

export interface PersistedState { memories:Memory[]; goals:Goal[]; events:JarvisEvent[]; personality:PersonalitySettings; world:WorldModel; self:SelfModel; }
