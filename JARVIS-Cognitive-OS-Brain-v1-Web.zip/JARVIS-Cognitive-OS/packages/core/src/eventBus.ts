import type {EventType, JarvisEvent} from './types.js';

export class EventBus {
  private listeners = new Map<EventType, Set<(e: JarvisEvent)=>void>>();
  emit<T>(type: EventType, payload:T, source:'web'|'android'|'core'='core'): JarvisEvent<T> {
    const event: JarvisEvent<T> = { id: crypto.randomUUID(), type, timestamp: Date.now(), source, payload };
    for (const fn of this.listeners.get(type) ?? []) fn(event as JarvisEvent);
    return event;
  }
  on(type: EventType, fn:(e:JarvisEvent)=>void):()=>void {
    let set=this.listeners.get(type); if(!set){set=new Set();this.listeners.set(type,set);} set.add(fn); return ()=>set?.delete(fn);
  }
}
