import type { ActionExecutor } from './action.js';
import { PolicyEngine } from './action.js';
import { EventBus } from './eventBus.js';
import { MemoryManager } from './memory.js';
import { generatePlans, predict, decide } from './planner.js';
import { LocalRuleEngine, ReasoningProvider } from './providers.js';
import type {
  DeviceState,
  Goal,
  PersonalitySettings,
  SelfModel,
  WorldModel,
  Plan,
} from './types.js';
import { MemoryStorage, StorageAdapter } from './storage.js';

export class JarvisCore {
  readonly bus = new EventBus();
  readonly memory: MemoryManager;
  readonly policy = new PolicyEngine();
  readonly provider: ReasoningProvider;
  readonly self: SelfModel = {
    currentMode: 'OFFLINE',
    currentThoughtState: 'ready',
    confidence: 0,
    uncertainty: 1,
    attention: 0,
    capabilities: [],
    limitations: ['لا يدّعي الوعي أو القدرات غير الممنوحة للبيئة'],
  };
  readonly personality: PersonalitySettings = {
    tone: 'professional',
    formality: 0.8,
    verbosity: 0.55,
    humor: 0.12,
    address: 'سيدي',
    explanationLevel: 0.7,
  };
  world: WorldModel = {
    user: '',
    time: Date.now(),
    currentRequest: '',
    availableTools: [],
    permissions: {},
    recentEvents: [],
    relevantMemory: [],
    deviceState: { platform: 'web', online: false, permissions: {} },
    pendingActions: [],
    results: [],
    constraints: [],
    uncertainty: 1,
  };

  private goals: Goal[] = [];
  private running = false;

  constructor(
    private storage: StorageAdapter = new MemoryStorage(),
    private executor?: ActionExecutor,
    provider: ReasoningProvider = new LocalRuleEngine(),
  ) {
    this.memory = new MemoryManager(storage, this.bus);
    this.provider = provider;
  }

  async init() {
    await this.memory.init();
    this.goals = (await this.storage.get<Goal[]>('goals')) ?? [];
    const savedSelf = await this.storage.get<SelfModel>('self');
    if (savedSelf) Object.assign(this.self, savedSelf);
    const savedP = await this.storage.get<PersonalitySettings>('personality');
    if (savedP) Object.assign(this.personality, savedP);
    const savedWorld = await this.storage.get<WorldModel>('world');
    if (savedWorld) this.world = { ...this.world, ...savedWorld };
  }

  async observe(device?: Partial<DeviceState>) {
    if (device) {
      this.world.deviceState = {
        ...this.world.deviceState,
        ...device,
        permissions: {
          ...this.world.deviceState.permissions,
          ...(device.permissions ?? {}),
        },
      };
      this.world.permissions = this.world.deviceState.permissions;
    }
    this.world.time = Date.now();
    this.self.lastObservation = `device=${this.world.deviceState.platform}, online=${this.world.deviceState.online}`;
    this.self.currentMode = this.world.deviceState.online ? 'IDLE' : 'OFFLINE';
    this.self.capabilities = Object.entries(this.world.deviceState.permissions)
      .filter(([, allowed]) => Boolean(allowed))
      .map(([key]) => key as any);
    this.bus.emit('OBSERVATION', { ...this.world.deviceState });
    await this.persist();
  }

  async handleInput(input: string): Promise<string> {
    if (this.running) return 'أنا مشغول بمهمة حالية؛ سأتعامل مع الطلب عند نقطة التحقق التالية.';
    this.running = true;
    this.world.currentRequest = input;
    this.self.currentMode = 'OBSERVING';
    this.self.attention = 1;
    this.bus.emit('USER_INPUT', { text: input });

    try {
      // Recall first so understanding can use the actual persistent context.
      this.self.currentMode = 'RECALLING';
      const memories = await this.memory.search(input, 8);
      this.world.relevantMemory = memories;

      this.self.currentMode = 'UNDERSTANDING';
      const context = JSON.stringify({
        goal: this.world.activeGoal,
        task: this.world.activeTask,
        memories: memories.map((m) => m.text),
      });
      const understanding = await this.provider.understand(input, context);
      this.self.uncertainty = understanding.ambiguity;
      this.self.confidence = 1 - understanding.ambiguity;

      if (understanding.intent === 'REMEMBER') {
        if (!understanding.memoryText || understanding.ambiguity > 0.5) {
          return 'أحتاج العبارة التي تريدني أن أتذكرها بشكل أوضح.';
        }
        this.self.currentMode = 'LEARNING';
        const type = understanding.memoryType ?? 'USER_FACT';
        const saved = await this.memory.add(type, understanding.memoryText, {
          importance: type === 'USER_PREFERENCE' ? 0.9 : 0.8,
          confidence: 0.95,
          tags: ['persistent', type.toLowerCase()],
        });
        this.self.lastDecision = `حفظ ${type}: ${saved.text}`;
        this.self.currentMode = 'IDLE';
        return type === 'USER_PREFERENCE'
          ? `تم حفظ تفضيلك في الذاكرة طويلة المدى: «${saved.text}».`
          : `تم حفظ المعلومة في الذاكرة طويلة المدى: «${saved.text}».`;
      }

      if (understanding.intent === 'RECALL') {
        this.self.currentMode = 'UNDERSTANDING';
        const preferences = this.memory.all().filter((m) => m.type === 'USER_PREFERENCE').slice(0, 8);
        const facts = this.memory.all().filter((m) => m.type === 'USER_FACT').slice(0, 5);
        if (!preferences.length && !facts.length) {
          return 'لا توجد لدي تفضيلات أو معلومات شخصية محفوظة حتى الآن.';
        }
        const lines = [
          ...preferences.map((m) => `• تفضيل: ${m.text}`),
          ...facts.map((m) => `• معلومة: ${m.text}`),
        ];
        return `من ذاكرتي الحالية:\n${lines.join('\n')}`;
      }

      if (understanding.intent === 'GOAL_QUERY') {
        const goal = this.world.activeGoal;
        if (!goal) return 'لا يوجد هدف نشط حاليًا.';
        return `هدفك الحالي هو: «${goal.title}».\nالهدف: ${goal.objective}\nالأولوية: ${(goal.priority * 100).toFixed(0)}%.`;
      }

      if (understanding.intent === 'GREETING') {
        return 'مرحبًا يا سيدي. النواة المعرفية جاهزة، والذاكرة والسياق متاحان.';
      }

      if (understanding.intent === 'DEVICE_ACTION') {
        return 'فهمت أنك تريد إجراءً على الجهاز، لكن بيئة الويب الحالية لا تمنحني صلاحية تنفيذ إجراءات Android. لن أدّعي تنفيذ شيء لم يحدث.';
      }

      if (understanding.intent === 'STUDY' || understanding.intent === 'PLANNING') {
        const subject = understanding.requestedSubject;
        if (!this.world.activeGoal) {
          const title = subject ? `مذاكرة ${subject}` : 'خطة المذاكرة';
          await this.createGoal(title, input);
        }
        if (subject && this.world.activeGoal) {
          this.world.activeGoal.objective = `${this.world.activeGoal.objective} — التركيز على ${subject}`;
          this.world.activeGoal.updatedAt = Date.now();
        }
        return await this.planCurrentGoal(memories);
      }

      this.self.currentMode = 'IDLE';
      const reply = await this.provider.answer(input, JSON.stringify({
        memories,
        world: this.world,
        self: this.self,
      }));
      await this.memory.add('CONVERSATION', `${input} => ${reply}`, { importance: 0.45 });
      return reply;
    } catch (err) {
      this.self.currentMode = 'BLOCKED';
      const msg = err instanceof Error ? err.message : String(err);
      this.bus.emit('ERROR', { message: msg });
      await this.memory.add('FAILURE', `فشل تنفيذ معالجة الطلب: ${msg}`, { importance: 0.8 });
      return `تعذر إكمال المعالجة بثقة: ${msg}`;
    } finally {
      this.running = false;
      this.self.attention = 0;
      await this.persist();
    }
  }

  private async planCurrentGoal(memories: Awaited<ReturnType<MemoryManager['search']>>) {
    if (!this.world.activeGoal) return 'لا يوجد هدف يمكن التخطيط له.';
    this.self.currentMode = 'PLANNING';
    this.self.currentGoal = this.world.activeGoal.id;

    const plans = generatePlans(this.world.activeGoal, memories, this.world.constraints);
    this.bus.emit('PLAN_CREATED', plans);
    const predictions = plans.map((p) => predict(p, this.world.activeGoal!));
    const decision = decide(
      plans,
      predictions,
      { speed: 0.65, quality: 0.85, riskAversion: 0.8 },
      memories,
    );
    const selected = plans.find((p) => p.id === decision.planId) as Plan;
    this.world.currentPlan = selected;
    this.self.currentMode = 'DECIDING';
    this.self.lastDecision = `${selected.label}: ${decision.reasons.join(' | ')}`;
    this.self.confidence = decision.confidence;
    this.self.uncertainty = 1 - decision.confidence;
    this.bus.emit('DECISION_MADE', {
      decision,
      predictions,
      plan: selected,
    });

    await this.memory.add('PLAN', `${selected.label}: ${selected.steps.join(' → ')}`, {
      importance: 0.7,
      confidence: decision.confidence,
      metadata: { goalId: this.world.activeGoal.id },
    });
    await this.memory.add('CONVERSATION', `${this.world.currentRequest} => خطة ${selected.label}`, {
      importance: 0.5,
    });

    this.self.currentMode = 'IDLE';
    const label = selected.label === 'FAST' ? 'السريعة' : selected.label === 'DEEP' ? 'العميقة' : 'المتوازنة';
    return `فهمت الهدف «${this.world.activeGoal.title}». اخترت الخطة ${label}.\n\n${selected.steps
      .map((step, index) => `${index + 1}. ${step}`)
      .join('\n')}\n\nالمخاطرة المقدرة: ${(selected.risk * 100).toFixed(0)}% — الثقة: ${(decision.confidence * 100).toFixed(0)}%.`;
  }

  async createGoal(title: string, objective: string) {
    const g: Goal = {
      id: crypto.randomUUID(),
      title,
      objective,
      status: 'ACTIVE',
      priority: 0.7,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    this.goals.unshift(g);
    this.world.activeGoal = g;
    this.bus.emit('GOAL_CREATED', g);
    await this.storage.set('goals', this.goals);
    await this.memory.add('GOAL', objective, { importance: 0.9, metadata: { goalId: g.id } });
    return g;
  }

  async execute(req: any) {
    if (!this.executor) return { id: req.id, success: false, error: 'لا يوجد منفّذ أفعال متصل بهذه البيئة', timestamp: Date.now() };
    const d = await this.executor.getDeviceState();
    const check = this.policy.check(req, d);
    if (!check.allowed) {
      this.bus.emit('PERMISSION_REQUIRED', { req, reason: check.reason });
      return { id: req.id, success: false, error: check.reason, timestamp: Date.now() };
    }
    this.bus.emit('ACTION_STARTED', req);
    const result = await this.executor.execute(req);
    this.world.results.unshift(result);
    this.bus.emit(result.success ? 'ACTION_COMPLETED' : 'ACTION_FAILED', result);
    return result;
  }

  async verify(statement: string, observed: unknown) {
    const ok = JSON.stringify(observed).toLowerCase().includes(statement.toLowerCase());
    this.bus.emit('VERIFICATION_COMPLETED', { statement, ok, observed });
    return ok;
  }

  async reflect() {
    this.self.currentMode = 'REFLECTING';
    const failures = this.memory.all().filter((m) => m.type === 'FAILURE').length;
    const lessons = this.memory.all().filter((m) => m.type === 'LESSON').length;
    const text = `تمت المراجعة: ${failures} فشل مسجل و${lessons} درس دائم.`;
    this.bus.emit('REFLECTION_COMPLETED', { text });
    this.self.currentMode = 'LEARNING';
    await this.memory.add('LESSON', text, { importance: 0.65 });
    this.bus.emit('LESSON_LEARNED', { text });
    this.self.currentMode = 'IDLE';
    await this.persist();
    return text;
  }

  async persist() {
    await this.storage.set('personality', this.personality);
    await this.storage.set('self', this.self);
    await this.storage.set('goals', this.goals);
    await this.storage.set('world', this.world);
  }

  snapshot() {
    return {
      self: { ...this.self },
      world: { ...this.world },
      memories: this.memory.all(),
      goals: [...this.goals],
      personality: { ...this.personality },
    };
  }
}
