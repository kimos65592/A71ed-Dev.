# J.A.R.V.I.S — Cognitive OS

A one-shot, offline-first cognitive architecture with a shared TypeScript Cognitive Core and two shells:

- **Web laboratory:** Vite web UI + IndexedDB persistence.
- **Android deployment shell:** native Kotlin WebView host that embeds the same compiled Cognitive Core/UI and exposes a device bridge.

## What is actually implemented

The core includes real modules for:

- Structured perception/event bus
- Intent/context understanding via `ReasoningProvider`
- Persistent memory with relevance/importance/recency ranking
- Self model + world model
- Goal creation and mission-ready state
- Multi-plan generation: FAST / BALANCED / DEEP
- Prediction and decision scoring using risk, confidence, cost and preferences
- Action/permission separation
- Verification hooks
- Reflection + persistent lessons
- Personality persistence
- Offline rule engine
- Provider abstraction for local model / remote model extensions
- Explicit failure instead of fake actions or fake permissions

## Run the web lab

```bash
npm install
npm run dev:web
```

Open the Vite URL shown in the terminal.

## Build Android APK with GitHub Actions

Push this repository to GitHub, then run the workflow **Build JARVIS APK**. It builds the web Cognitive UI, copies it into Android assets, and assembles a debug APK.

## Important truth about Android

The Android shell contains the native bridge points and background-service architecture, but Android itself controls access to microphone, notifications, accessibility, files, media and other protected capabilities. JARVIS never assumes those capabilities exist; the bridge must report the actual device state.

The notification listener service is a native ingress point. Accessibility and wake-word engines are intentionally permission-gated extension points rather than fake implementations.

## Architecture

```text
                 J.A.R.V.I.S
                       |
                Cognitive Core
                       |
      +----------------+----------------+
      |                                 |
   Web Shell                       Android Shell
      |                                 |
   IndexedDB                     WebView + Native Bridge
      |                                 |
 Browser events                 OS services / permissions
```

The core does not claim consciousness. “Awareness” is represented as computational self-monitoring fields in the Self Model.
