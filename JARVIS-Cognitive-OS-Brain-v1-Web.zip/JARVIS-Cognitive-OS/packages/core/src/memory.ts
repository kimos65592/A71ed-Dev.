import type {Memory, MemoryType} from './types.js';
import {StorageAdapter} from './storage.js';
import {EventBus} from './eventBus.js';

const tokenize=(s:string)=>new Set(s.toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}\s]/gu,' ').split(/\s+/).filter(Boolean));
export class MemoryManager {
  private memories:Memory[]=[];
  constructor(private storage:StorageAdapter, private bus:EventBus){}
  async init(){this.memories=await this.storage.get<Memory[]>('memories')??[];}
  async add(type:MemoryType,text:string,options?:{tags?:string[];importance?:number;confidence?:number;metadata?:Record<string,unknown>}){
    const now=Date.now(); const m:Memory={id:crypto.randomUUID(),type,text,tags:options?.tags??[],importance:options?.importance??0.5,createdAt:now,updatedAt:now,lastAccessedAt:now,confidence:options?.confidence??0.8,metadata:options?.metadata};
    this.memories.unshift(m); await this.storage.set('memories',this.memories); this.bus.emit('MEMORY_UPDATED',m); return m;
  }
  async search(query:string,limit=8){
    const q=tokenize(query); const now=Date.now();
    const ranked=this.memories.map(m=>{const mt=tokenize(m.text+' '+m.tags.join(' '));let overlap=0;q.forEach(t=>{if(mt.has(t))overlap++;}); const recency=Math.max(0,1-(now-m.lastAccessedAt)/(1000*60*60*24*30)); const score=overlap*2+m.importance*1.5+m.confidence+recency;return {m,score};}).filter(x=>x.score>1.5).sort((a,b)=>b.score-a.score).slice(0,limit).map(x=>x.m);
    for(const m of ranked)m.lastAccessedAt=now; await this.storage.set('memories',this.memories); this.bus.emit('MEMORY_RETRIEVED',ranked); return ranked;
  }
  async forget(id:string){this.memories=this.memories.filter(m=>m.id!==id);await this.storage.set('memories',this.memories);this.bus.emit('MEMORY_UPDATED',{forgottenId:id});}
  all(){return [...this.memories];}
}
