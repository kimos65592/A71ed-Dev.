import type {ActionRequest,ActionResult,Capability,DeviceState} from './types.js';

export interface ActionExecutor { execute(req:ActionRequest):Promise<ActionResult>; getDeviceState():Promise<DeviceState>; hasCapability(cap:Capability):boolean; }
export class PolicyEngine {
  check(req:ActionRequest, device:DeviceState):{allowed:boolean;reason?:string}{
    if(!device.permissions[req.capability] && req.capability!=='READ_DEVICE_STATE') return {allowed:false,reason:`الصلاحية/القدرة ${req.capability} غير متاحة`};
    return {allowed:true};
  }
}
