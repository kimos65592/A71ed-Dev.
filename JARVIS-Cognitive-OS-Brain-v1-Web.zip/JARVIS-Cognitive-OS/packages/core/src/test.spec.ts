import {describe,it,expect} from 'vitest';
import {JarvisCore} from './core.js';
import {MemoryStorage} from './storage.js';

describe('JARVIS cognitive core',()=>{
 it('persists memory and retrieves relevant context',async()=>{const s=new MemoryStorage();const j=new JarvisCore(s);await j.init();await j.memory.add('USER_PREFERENCE','يفضل المذاكرة بخطة متوازنة',{importance:.9});const r=await j.memory.search('خطة متوازنة');expect(r.length).toBeGreaterThan(0);expect(r[0].text).toContain('متوازنة');});
 it('keeps follow-up context as active goal',async()=>{const j=new JarvisCore(new MemoryStorage());await j.init();await j.observe({platform:'web',online:false});await j.handleInput('جهزني لمذاكرة البرمجة');expect(j.world.activeGoal).toBeTruthy();const first=j.world.activeGoal?.id;await j.handleInput('ابدأ');expect(j.world.activeGoal?.id).toBe(first);});
 it('reports lack of executor instead of faking action',async()=>{const j=new JarvisCore(new MemoryStorage());await j.init();const r=await j.execute({id:'1',capability:'OPEN_APP',action:'open',args:{package:'x'}});expect(r.success).toBe(false);});
});
