import { defineConfig } from 'vite';
import path from 'node:path';

export default defineConfig({
  base: '/THUNDERFIRE-OS/',
  server: { host: '0.0.0.0', port: 5173 },
  build: { outDir: 'dist' },
  resolve: {
    alias: {
      '@jarvis/core': path.resolve(__dirname, '../../packages/core/src'),
    },
  },
});
