import {JarvisCore, IndexedDbStorage} from '@jarvis/core';
import './style.css';

const app=document.querySelector('#app')!;
app.innerHTML=`<div class="shell">
<header><div><div class="brand">J.A.R.V.I.S</div><div class="sub">COGNITIVE OPERATING SYSTEM</div></div><div id="status" class="pill">OFFLINE</div></header>
<main>
<section class="hero"><div><h1>العقل المعرفي</h1><p>مختبر الويب للنواة نفسها التي يستهلكها غلاف أندرويد. لا توجد نسب عشوائية ولا ادعاءات بقدرات غير ممنوحة.</p></div><button id="clear">مسح الذاكرة المحلية</button></section>
<section class="grid"><div class="panel"><h2>المحادثة</h2><div id="chat" class="chat"></div><div class="composer"><textarea id="input" placeholder="مثال: أنا متأخر وعندي مذاكرة برمجة..."></textarea><button id="send">تنفيذ</button></div></div>
<div class="panel"><h2>الحالة الداخلية</h2><div id="state" class="state"></div></div>
<div class="panel wide"><h2>سجل الأحداث المعرفية</h2><pre id="events" class="events"></pre></div>
<div class="panel"><h2>الذاكرة</h2><div id="memory" class="memory"></div></div>
<div class="panel"><h2>الهدف والخطة</h2><div id="goal" class="goal"></div></div></section>
</main></div>`;

const core=new JarvisCore(new IndexedDbStorage());
const events:any[]=[];
const $=(s:string)=>document.querySelector(s)!;
function bubble(who:string,text:string){const el=document.createElement('div');el.className='bubble '+(who==='JARVIS'?'jarvis':'user');el.innerHTML=`<b>${who}</b><div>${text.replace(/\n/g,'<br>')}</div>`;($('#chat') as HTMLElement).appendChild(el);($('#chat') as HTMLElement).scrollTop=99999;}
function esc(s:string){return s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]!));}
function render(){const s=core.snapshot();($('#status') as HTMLElement).textContent=s.self.currentMode==='OFFLINE'?'OFFLINE':'ONLINE';($('#status') as HTMLElement).className='pill '+(s.self.currentMode==='OFFLINE'?'off':'on');$('#state').innerHTML=`<div><span>MODE</span><strong>${s.self.currentMode}</strong></div><div><span>CONFIDENCE</span><strong>${(s.self.confidence*100).toFixed(0)}%</strong></div><div><span>UNCERTAINTY</span><strong>${(s.self.uncertainty*100).toFixed(0)}%</strong></div><div><span>ATTENTION</span><strong>${(s.self.attention*100).toFixed(0)}%</strong></div><div><span>OBSERVATION</span><strong>${esc(s.self.lastObservation??'—')}</strong></div><div><span>DECISION</span><strong>${esc(s.self.lastDecision??'—')}</strong></div>`;
 $('#memory').innerHTML=s.memories.slice(0,8).map(m=>`<article><b>${m.type}</b><div>${esc(m.text)}</div><small>imp ${(m.importance*100).toFixed(0)}%</small></article>`).join('')||'<span>لا توجد ذكريات بعد.</span>';
 const g=s.world.activeGoal,p=s.world.currentPlan;$('#goal').innerHTML=g?`<b>${esc(g.title)}</b><p>${esc(g.objective)}</p>${p?`<hr><b>PLAN ${p.label}</b><ol>${p.steps.map(x=>`<li>${esc(x)}</li>`).join('')}</ol><p>risk ${(p.risk*100).toFixed(0)}% · confidence ${(p.confidence*100).toFixed(0)}%</p>`:''}`:'لا يوجد هدف نشط.';
 ($('#events') as HTMLElement).textContent=events.slice(-40).map(e=>`${new Date(e.timestamp).toLocaleTimeString()} | ${e.type} | ${JSON.stringify(e.payload).slice(0,240)}`).join('\n');}
const types=['OBSERVATION','USER_INPUT','MEMORY_RETRIEVED','MEMORY_UPDATED','GOAL_CREATED','GOAL_UPDATED','PLAN_CREATED','DECISION_MADE','ACTION_REQUESTED','PERMISSION_REQUIRED','ACTION_STARTED','ACTION_COMPLETED','ACTION_FAILED','VERIFICATION_COMPLETED','REFLECTION_COMPLETED','LESSON_LEARNED','DEVICE_EVENT','NOTIFICATION_EVENT','ERROR'] as const;
(async()=>{await core.init();await core.observe({platform:'web',online:navigator.onLine,permissions:{READ_DEVICE_STATE:true}});types.forEach(t=>core.bus.on(t as any,e=>{events.push(e);render();}));render();bubble('JARVIS','النواة جاهزة. أنا نظام حاسوبي، ولست واعيًا بالمعنى البشري.');})();
$('#send').addEventListener('click',async()=>{const v=(($('#input') as HTMLTextAreaElement).value).trim();if(!v)return;bubble('USER',v);($('#input') as HTMLTextAreaElement).value='';const r=await core.handleInput(v);bubble('JARVIS',r);render();});
$('#input').addEventListener('keydown',e=>{if((e as KeyboardEvent).key==='Enter'&&(e as KeyboardEvent).ctrlKey){($('#send') as HTMLButtonElement).click();}});
$('#clear').addEventListener('click',async()=>{const db=indexedDB.open('jarvis-db');db.onsuccess=()=>{const d=db.result;const tx=d.transaction('kv','readwrite');tx.objectStore('kv').clear();tx.oncomplete=()=>location.reload();};});
